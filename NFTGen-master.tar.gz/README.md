# NFT Image Generator
Utility for creating generative art from supplied image layers, especially made for making NFT collectibles. 
The tool generates the total number of images according to the given rarity table.

![image](https://user-images.githubusercontent.com/6986779/138673636-b5f38c20-e3a9-49b9-9957-ec125805680f.png)
![image](https://user-images.githubusercontent.com/6986779/138673704-6bcb1f2a-5c0b-4f57-8dc0-97086f90b567.png)
![image](https://user-images.githubusercontent.com/6986779/138673840-f423f768-94c0-4ecf-892c-cc8302e01a58.png)
